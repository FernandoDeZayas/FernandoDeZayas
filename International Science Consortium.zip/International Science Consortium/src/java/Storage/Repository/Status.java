/*
 * Arelys De La Guardia
 * Deisy Hernandez
 * Michael Smythers
 * Daniel Galano
 * Jairo Pava
 *
 * International Science Consoritum Control System
 *
 * December 1, 2009
 */

package Storage.Repository;

import java.sql.Timestamp;

public class Status
{
    public String Title;
    public String Comments;
    public Timestamp Date;
}
