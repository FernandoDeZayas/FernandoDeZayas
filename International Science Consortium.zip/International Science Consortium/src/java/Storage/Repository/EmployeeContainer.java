/*
 * Arelys De La Guardia
 * Deisy Hernandez
 * Michael Smythers
 * Daniel Galano
 * Jairo Pava
 *
 * International Science Consoritum Control System
 *
 * December 1, 2009
 */

package Storage.Repository;

/**
 * This class is responsible for all employee related operations in the database (get employee). It receives the respective entity objects and converts them into the appropriate SQL queries.
**/
public class EmployeeContainer {
	/**
	 * Get Employee from  the Database
	 *
	 * @param    ID
	**/
	public EmployeeProfile getEmployee(int ID) {
	return null;
	}
}
