package search.models;

import com.mysql.jdbc.Connection;

public class Search {

	public boolean doSearch(String searchKeyword) 
	{
		try {			
			Connection connection = null;
			
			connection = DBDriver.connect();
			return DBStubs.doSearch(searchKeyword, connection);
		} 
		catch (Exception e) {
			System.out.println(" Error inserting into the database:  " + e);
			return false;
		}
		
	}
	
	public boolean doIPCheck(String ipAddress) 
	{
		try {			
			Connection connection = null;
			
			connection = DBDriver.connect();
			return DBStubs.doIPCheck(ipAddress, connection);
		} 
		catch (Exception e) {
			System.out.println(" Error inserting into the database:  " + e);
			return false;
		}
		
	}
	
	public boolean insertIPAddress(String ipAddress) 
	{
		try {			
			Connection connection = null;
			
			connection = DBDriver.connect();
			return DBStubs.insertIPAddress(ipAddress, connection);
		} 
		catch (Exception e) {
			System.out.println(" Error inserting into the database:  " + e);
			return false;
		}
		
	}
	
	public String[] getStockInfo(String ticker) 
	{
		try {			
			Connection connection = null;
			
			connection = DBDriver.connect();
			return DBStubs.getStockInfo(ticker, connection);
		} 
		catch (Exception e) {
			System.out.println(" Error inserting into the database:  " + e);
			return null;
		}
		
	}

}
