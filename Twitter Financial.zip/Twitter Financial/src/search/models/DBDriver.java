package search.models;

import java.sql.DriverManager;
import java.sql.SQLException;
import com.mysql.jdbc.Connection;

public class DBDriver {
	
	public static Connection connect () throws SQLException
	{
		String connectionURL = "jdbc:mysql://localhost:3306/twitterFinancial";
		Connection connection = null;
		String dbUsername = "mherr059";
		String dbPassword = "soccer11";
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (Exception e) {
			System.out.println(" Unable to load driver. ");
		}
		
		connection = (Connection) DriverManager.getConnection(connectionURL, dbUsername, dbPassword);
		System.out.println(" Connection Established. ");
		
		return connection;	
	}

}

