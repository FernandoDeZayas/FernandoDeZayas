package search.models;

import java.util.ArrayList;

public class Facade {
	
	// Feature - Search
	public boolean doSearch(String searchKeyword)
	{
		Search search = new Search();

		return search.doSearch(searchKeyword);
	}
	
	// Feature - IP Check
		public static boolean doIPCheck(String ipAddress)
		{
			Search search = new Search();

			return search.doIPCheck(ipAddress);
		}
		
		// Feature - Search
		public static boolean insertIPAddress(String ipAddress)
		{
			Search search = new Search();

			return search.insertIPAddress(ipAddress);
		}
	
//	public static String[] getStockInfo(String ticker) 
//	{
//		return Search.getStockInfo(ticker);
//	}
	
//	// Feature - Login
//	public static boolean doLogin(String username, String password) 
//	{
//		return User.doLogin(username, password);
//	}
//	
//	// Feature - Company
//	public static ArrayList<Company> getCompanies()
//	{
//		return Company.getCompanies();
//	}
	
}
