package search.models;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;

public class DBStubs {
	
	public static boolean doIPCheck(String ipAddress, Connection connection) throws SQLException
	{

		ResultSet rs = null;
		
		PreparedStatement st = (PreparedStatement) connection.prepareStatement("SELECT * FROM search WHERE ipaddress = ?");
		st.setString(1, ipAddress);
		rs = st.executeQuery();
	
		//return false if email already taken
		if (rs == null) {
			connection.close();
			return false;
		} else {
			return true;
		}
	}
	
	public static boolean insertIPAddress(String ipAddress, Connection connection) throws SQLException
	{

		String query = "INSERT INTO search (" + " ipaddress ) VALUES (" + "?)";

		PreparedStatement st = (PreparedStatement) connection.prepareStatement(query);
		st.setString(1, ipAddress);
		st.executeUpdate();
		
		connection.close();
		
		return true;
	}
	
	public static boolean doSearch(String searchKeyword, Connection connection) throws SQLException
	{

		ResultSet rs = null;
		
		PreparedStatement st = (PreparedStatement) connection.prepareStatement("SELECT * FROM Users WHERE username = ?");
		st.setString(1, searchKeyword);
		rs = st.executeQuery();
	
		//return false if email already taken
		if (rs == null) {
			connection.close();
			return false;
		} else {
			String query = "INSERT INTO Users (" + " username," + " fname,"
					+ " lname," + " password," + " privileges ) VALUES (" + "?, ?, ?, ?, ?)";

			st = (PreparedStatement) connection.prepareStatement(query);
			st.setString(1, searchKeyword);
			st.executeUpdate();
			
			connection.close();
		}
		
		return true;
	}
	
	public static String[] getStockInfo(String ticker, Connection connection) throws SQLException
	{
		String [] row = new String[4];

		ResultSet rs = null;
		
		PreparedStatement st = (PreparedStatement) connection.prepareStatement("SELECT * FROM Users WHERE username = ?");
		st.setString(1, ticker);
		rs = st.executeQuery();

		if (rs != null) {			
			
			while (rs.next()) {
				 row[0] = rs.getString("username");
				 row[1] = rs.getString("fname");
				 row[2] = rs.getString("lname");
				 row[3] = rs.getString("privileges");
			}
		}
		
		return row;
	}
	
	public static boolean doLogin(String username, String password, Connection connection) throws SQLException 
	{
		ResultSet rs = null;
		
		PreparedStatement st = (PreparedStatement) connection
				.prepareStatement("SELECT username, password FROM Users WHERE username = ?");
		st.setString(1, username);
		rs = st.executeQuery();

		if (rs != null) {
			String user = "";
			String pass = "";

			while (rs.next()) {
				user = rs.getString("username");
				pass = rs.getString("password");
			}

			connection.close();
			if (username.compareTo(user) == 0
					&& password.compareTo(pass) == 0)
				return true;
		}
		
		return false;
	}
	
//	public static ArrayList<Company> findNoAdmin(Connection connection) throws SQLException {
//
//		ArrayList<User> nonAdmin = new ArrayList<User>();
//
//		ResultSet rs = null;
//
//		PreparedStatement st = (PreparedStatement) connection
//				.prepareStatement("SELECT username, fname, lname, privileges FROM Users WHERE privileges = ?");
//		st.setString(1, "u");
//		rs = st.executeQuery();
//
//		if (rs != null) {
//			String user = "";
//			String fname = "";
//			String lname = "";
//			String privileges = "";
//
//			while (rs.next()) {
//				user = rs.getString("username");
//				fname = rs.getString("fname");
//				lname = rs.getString("lname");
//				privileges = rs.getString("privileges");
//
//				User user1 = new User(user, fname, lname, privileges);
//
//				nonAdmin.add(user1);
//				// System.out.println(user);
//			}
//			connection.close();
//		}
//
//		return nonAdmin;
//	}
	
}
