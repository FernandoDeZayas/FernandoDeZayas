package search.tests;

import static org.junit.Assert.*;
import org.junit.Test;

import search.models.Facade;

public class UnitTest {
	
	Facade face = new Facade();
	
	// =============== SearchDoSearchUnitTest ==================
	@Test
	public void TF_Search_Unit_DoSearch_01() {
		assertTrue(face.doSearch("goog"));
	}
	
	@Test
	public void TF_Search_Unit_DoSearch_02() {
		assertTrue(face.doSearch(""));
	}
	
	@Test
	public void TF_Search_Unit_DoSearch_03() {
		assertTrue(face.doSearch("miguel"));
	}
	
	@Test
	public void TF_Search_Unit_DoSearch_04() {
		assertTrue(face.doSearch("-1"));
	}
	
	
}

