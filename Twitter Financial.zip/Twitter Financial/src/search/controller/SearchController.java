package search.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Map;
import java.util.Scanner;
import java.util.UUID;

import java.math.BigDecimal;
import twitter4j.Query;
import twitter4j.Query;
import twitter4j.QueryResult;
import twitter4j.Status;
import twitter4j.Twitter;
import java.util.Scanner;
import twitter4j.TwitterException;
import yahoofinance.Stock;
import yahoofinance.YahooFinance;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import search.models.Search;
import search.models.Facade;
import search.models.User;
import softwareEnginering.MentionPumpSymbols;
import softwareEnginering.StockInfo;
import softwareEnginering.TwitterRetry;

/**
 * Servlet implementation class SearchController
 */
@WebServlet("/SearchController")
public class SearchController extends HttpServlet {
	
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public SearchController() 
	{
		super();
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		
//		//is client behind something?
////	   String ipAddress = request.getHeader("X-FORWARDED-FOR");  
////	   if (ipAddress == null) {  
////		   ipAddress = request.getRemoteAddr();  
////	   }
//		String ipAddress = "123";
//	   
//	   System.out.println("ip"+ipAddress);
//		
//		Facade face = new Facade();
////		
//		boolean ipCheck = Facade.doIPCheck(ipAddress);
//		
//		if(ipCheck==true)
//		{
//			request.setAttribute("message",
//					"IPCheck failed");
//			response.sendRedirect("welcome.jsp");
//		}
////		
		String ipAddress = "123";
//		
		// String forward = "/FamilyTree/"; // Used to redirect browser

		// Get a map of the request parameters
		@SuppressWarnings("unchecked")
		Map parameters = request.getParameterMap();

		// request from registration page
		if (parameters.containsKey("search")) {

			String ticker = request.getParameter("ticker");
			
			if(ticker=="")
			{
//				request.setAttribute("message",
//						"Ticker cannot be null");
				//response.sendRedirect("welcome.jsp");
			}
				

			TwitterRetry TR=new TwitterRetry();
	        Scanner in = new Scanner(System.in);                
//	        if(ticker.isEmpty()){System.out.println("the ticker is empty");return;}
//	        if(ticker.length() > 5){System.out.println("the ticker is too long");return;}
	        ticker="$"+ticker.toUpperCase();
	        StockInfo stock= new StockInfo(ticker.substring(1));
	        String stockInfo = stock.Print2();
	        
	        int semantics;
			try {
				semantics = MentionPumpSymbols.SearchSemanticsStocks(ticker,TR);
			} catch (TwitterException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				semantics = Integer.MAX_VALUE;				
			}
	        if(semantics != Integer.MAX_VALUE)
	        {
	        	Facade.insertIPAddress(ipAddress);
	        	
	            if(semantics<=0)request.setAttribute("semantics",
						"http://www.clipartbest.com/cliparts/dc7/eBd/dc7eBd8Ri.png");else
	            if(semantics > 0)request.setAttribute("semantics",
						"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTVirR35RExIBVTI8qk5R-oIdQ8j5_bQWpAg6R11Ihtm9BVOZPl");
	            request.setAttribute("stockInfo",
						stockInfo);
	            
	        }else
	        {
//	        	request.setAttribute("message",
//						"An error occured");
	        	//response.sendRedirect("welcome.jsp");
	        }
	        request.getRequestDispatcher("company-view.jsp").forward(
 					request, response);
	       
		}

		// Request from login
//		if (parameters.containsKey("login")) {
//
//			// Setup response
//			response.setContentType("text/html;charset=UTF-8");
//
//			// Get values from JSP
//			String username = request.getParameter("username");
//			String password = request.getParameter("password");
//
//			// doLogin
//			HttpSession session = request.getSession(true);
//
//			if (!username.equals("") && !password.equals("")
//					&& Facade.doLogin(username, password)) {
//
//				// get complete name of user that log in
//				//String[] row = Facade.getUserInfo(username);
//				String[] row = null;
//				
//				// get the whole list of comments
//				//ArrayList<Search> mylist = Facade.getSearchLog();
//				//int total_searches = mylist.size();
//
//				// Create unique session
//				String sessionID = UUID.randomUUID().toString();
//				session.setAttribute("username", username);
//				session.setAttribute("sessionID", sessionID);
//				session.setAttribute("fname", row[1]);
//				session.setAttribute("lname", row[2]);
//				session.setAttribute("privileges", row[3]);
//
//				//request.setAttribute("comments", mylist);
//				//request.setAttribute("total_comments", total_comments);
//
//				// Redirect to landing page
//				if (row[3].equals("s")) {
//					ArrayList<User> nonAdmin = Facade.findNoAdmin();
//					ArrayList<User> requests = Facade
//							.showAdminRequest();
//					request.setAttribute("nonAdmin", nonAdmin);
//					request.setAttribute("requests", requests);
//				} else {
//					ArrayList<User> nonAdmin = new ArrayList<User>();
//					ArrayList<User> requests = new ArrayList<User>();
//					request.setAttribute("nonAdmin", nonAdmin);
//					request.setAttribute("requests", requests);
//				}
//				request.getRequestDispatcher("welcome.jsp").forward(request,
//						response);
//			}
//			// If either field was left empty
//			else if (username.equals("") || password.equals("")) {
//				request.setAttribute("message",
//						"Please enter Email and Password");
//				request.getRequestDispatcher("login.jsp").forward(request,
//						response);
//			}
//			// Otherwise, username/password combination is incorrect
//			else {
//				request.setAttribute("message",
//						"Invalid email/password combination"); // Will be
//																// available as
//																// ${message}
//				request.getRequestDispatcher("login.jsp").forward(request,
//						response);
//			}
//		}

		// Perform logout
		if (parameters.containsKey("logout")) {
			HttpSession session = request.getSession();
			session.invalidate();

			response.sendRedirect("welcome.jsp");
		}


	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		HttpSession session = request.getSession();

		// Get a map of the request parameters
		@SuppressWarnings("unchecked")
		Map parameters = request.getParameterMap();

		if (parameters.containsKey("submit")) {

		}

	}
}
